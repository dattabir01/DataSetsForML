from flask import Flask, request
import tensorflow as tf
import numpy as np
from keras.models import load_model
from tensorflow.python.keras.backend import set_session
import keras
import flask

# Declare the server instance
app = Flask(__name__)

# start a tf session BEFORE loading the model
session = tf.Session()

# load and graph and model
graph = tf.get_default_graph()
set_session(session)
model = load_model('newm.h5')

# very simple get API for prediction
# very critical syntax: do not leave a line between app.route and def in next line
@app.route('/simple',methods=['GET','POST'])
def predictSimple():
    if request.method =='GET':
        a = request.args['a']
        b = request.args['b']
    elif request.method == 'POST':
        a = request.form['a']
        b = request.form['b']
    with graph.as_default():
        try:
            set_session(session)
            data = np.array([[a,b]])
            result = model.predict(data)[0].tolist()
            result = 1 if result[0]>0.5 else 0 
            response = {'result':result}
        except Exception as exp:
            response = {'result':str(exp) }
        return flask.jsonify(response)

@app.route('/')
def welcome():
    return "Bye bye world"

app.run(port=5000, debug=False)









            
